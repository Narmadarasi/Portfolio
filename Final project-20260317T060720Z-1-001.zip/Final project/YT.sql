CREATE TABLE youtube_trending_videos (
    video_id                VARCHAR(50) NOT NULL,
    trending_date           DATE NOT NULL,
    title                   TEXT,
    channel_title           TEXT,
    category_id             INTEGER,
    publish_time            TIMESTAMP,
    tags                    TEXT,
    views                   BIGINT,
    likes                   BIGINT,
    dislikes                BIGINT,
    comment_count           BIGINT,
    thumbnail_link          TEXT,
    comments_disabled       BOOLEAN,
    ratings_disabled        BOOLEAN,
    video_error_or_removed  BOOLEAN,
    description             TEXT,
    country                 VARCHAR(10) NOT NULL,
    category_name           TEXT,

    -- Composite Primary Key
    CONSTRAINT pk_video_trending
        PRIMARY KEY (video_id, trending_date, country)
);
SET datestyle = 'ISO, DMY';
CREATE TABLE youtube_trending_testing (
    video_id VARCHAR(50),
    trending_date DATE,
    title TEXT,
    channel_title TEXT,
    category_id INTEGER,
    publish_time TIMESTAMP,
    tags TEXT,
    views BIGINT,
    likes BIGINT,
    dislikes BIGINT,
    comment_count BIGINT,
    thumbnail_link TEXT,
    comments_disabled BOOLEAN,
    ratings_disabled BOOLEAN,
    video_error_or_removed BOOLEAN,
    description TEXT,
    country VARCHAR(10),
    category_name TEXT,
	engagement_rate NUMERIC,
    like_ratio NUMERIC,
    title_length INTEGER,
    tag_count INTEGER,
    time_to_trend INTEGER
);

INSERT INTO youtube_trending_videos
SELECT DISTINCT *
FROM youtube_trending_testing
ON CONFLICT (video_id, trending_date, country) DO NOTHING;

select * from youtube_trending_videos;
select distinct country from youtube_trending_videos;
select distinct (category_name)from youtube_trending_videos
where category_id = 29;

/* ================================
   YOUTUBE TRENDING ANALYSIS
   30 SQL QUERIES – SINGLE SCRIPT
   Table: youtube_trending_videos
================================ */

/* 1. Total videos */
SELECT COUNT(*) AS total_videos
FROM youtube_trending_videos;

/* 2. Unique channels */
SELECT COUNT(DISTINCT channel_title) AS total_channels
FROM youtube_trending_videos;

/* 3. Unique categories */
SELECT COUNT(DISTINCT category_id) AS total_categories
FROM youtube_trending_videos;

/* 4. Date-wise trending count */
SELECT trending_date, COUNT(*) AS videos_count
FROM youtube_trending_videos
GROUP BY trending_date
ORDER BY trending_date;

/* 5. Comments disabled videos */
SELECT COUNT(*) AS comments_disabled_count
FROM youtube_trending_videos
WHERE comments_disabled ='TRUE';

/* 6. Top 10 most viewed videos */
SELECT title, views
FROM youtube_trending_videos
ORDER BY views DESC LIMIT 10;

/* 7. Average views */
SELECT AVG(views) AS avg_views
FROM youtube_trending_videos;

/* 8. Category-wise total views */
SELECT category_id, SUM(views) AS total_views
FROM youtube_trending_videos
GROUP BY category_id
ORDER BY total_views DESC;

/* 9. Channel with highest views */
SELECT channel_title, SUM(views) AS total_views
FROM youtube_trending_videos
GROUP BY channel_title
ORDER BY total_views DESC LIMIT 1;

/* 10. Videos with >10M views */
SELECT title, views
FROM youtube_trending_videos
WHERE views > 10000000;

/* 11. Average engagement rate */
SELECT AVG(engagement_rate) AS avg_engagement
FROM youtube_trending_videos;

/* 12. Top 10 engagement videos */
SELECT  title, engagement_rate
FROM youtube_trending_videos
ORDER BY engagement_rate DESC LIMIT 10;

/* 13. Category-wise engagement */
SELECT category_id, AVG(engagement_rate) AS avg_engagement
FROM youtube_trending_videos
GROUP BY category_id
ORDER BY avg_engagement DESC;

/* 14. Zero engagement videos */
SELECT title
FROM youtube_trending_videos
WHERE engagement_rate = 0;

/* 15. Channel-wise avg engagement */
SELECT channel_title, AVG(engagement_rate) AS avg_engagement
FROM youtube_trending_videos
GROUP BY channel_title
ORDER BY avg_engagement DESC;

/* 16. Average like ratio */
SELECT AVG(like_ratio) AS avg_like_ratio
FROM youtube_trending_videos;

/* 17. Low like ratio videos */
SELECT title, like_ratio
FROM youtube_trending_videos
WHERE like_ratio < 0.5;

/* 18. Top commented videos */
SELECT title, comment_count
FROM youtube_trending_videos
ORDER BY comment_count DESC LIMIT 10;

/* 19. Comments disabled but high views */
SELECT title, views
FROM youtube_trending_videos
WHERE comments_disabled = 'FALSE'
ORDER BY views DESC;

/* 20. Category-wise avg comments */
SELECT category_id, AVG(comment_count) AS avg_comments
FROM youtube_trending_videos
GROUP BY category_id;

/* 21. Average title length */
SELECT AVG(title_length) AS avg_title_length
FROM youtube_trending_videos;

/* 22. Very long titles */
SELECT title, title_length
FROM youtube_trending_videos
WHERE title_length > 100;

/* 23. Average tag count */
SELECT AVG(tag_count) AS avg_tag_count
FROM youtube_trending_videos;

/* 24. Videos without tags */
SELECT title
FROM youtube_trending_videos
WHERE tag_count = 0;

/* 25. Tag count vs engagement */
SELECT tag_count, AVG(engagement_rate) AS avg_engagement
FROM youtube_trending_videos
GROUP BY tag_count
ORDER BY tag_count;

/* 26. Average time to trend */
SELECT AVG(time_to_trend) AS avg_time_to_trend
FROM youtube_trending_videos;

/* 27. Fastest trending videos */
SELECT title, time_to_trend
FROM youtube_trending_videos
ORDER BY time_to_trend ASC LIMIT 10;

/* 28. Slow trending videos (>30 days) */
SELECT title, time_to_trend
FROM youtube_trending_videos
WHERE time_to_trend > 30;

/* 29. Month-wise trending count */
SELECT 
    EXTRACT(MONTH FROM trending_date) AS trend_month,
    COUNT(*) AS videos_count
FROM youtube_trending_videos
GROUP BY trend_month
ORDER BY trend_month;


/* 30. Best publish day (fast trend) */
SELECT 
    TO_CHAR(publish_time, 'Day') AS publish_day,
    AVG(time_to_trend) AS avg_days_to_trend
FROM youtube_trending_videos
GROUP BY publish_day
ORDER BY avg_days_to_trend;



